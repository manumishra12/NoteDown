export type NoteInfo = {
  title: string
  lastEditTime: number
}

export type NoteContent = string
