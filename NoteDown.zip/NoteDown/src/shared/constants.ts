export const appDirectoryName = 'NoteMark'
export const fileEncoding = 'utf8'

export const autoSavingTime = 3000
export const welcomeNoteFilename = 'Welcome.md'
